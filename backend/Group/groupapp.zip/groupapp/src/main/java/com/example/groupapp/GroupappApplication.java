package com.example.groupapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GroupappApplication {

	public static void main(String[] args) {
		SpringApplication.run(GroupappApplication.class, args);
	}

}
